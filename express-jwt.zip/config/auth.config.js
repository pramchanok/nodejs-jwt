module.exports = {
  secret: "devvip-secret-key",
};
